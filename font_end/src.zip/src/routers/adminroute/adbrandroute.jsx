import AdBrandPage from '../../pages/admin/thuonghieu/AdBrandPage'

const adBrandRoute = [{ path: '/admin/brand', element: <AdBrandPage /> }]

export default adBrandRoute
