import AdMaterialPage from '../../pages/admin/chatlieu/AdMaterialPage'

const adMaterialRoute = [{ path: '/admin/material', element: <AdMaterialPage /> }]

export default adMaterialRoute
