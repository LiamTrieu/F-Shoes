import AdColorPage from '../../pages/admin/color/AdColorPage'

const adColorRoute = [{ path: '/admin/color', element: <AdColorPage /> }]

export default adColorRoute
