import AdCategoryPage from '../../pages/admin/theloai/AdCategoryPage'

const adCategoryRoute = [{ path: '/admin/category', element: <AdCategoryPage /> }]

export default adCategoryRoute
