import AdSolePage from '../../pages/admin/sole/AdSolePage'

const adSoleRoute = [
  { path: '/admin/sole', element: <AdSolePage /> },
]

export default adSoleRoute
