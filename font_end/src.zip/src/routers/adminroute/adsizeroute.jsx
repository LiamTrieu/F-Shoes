import AdSizePage from '../../pages/admin/size/AdSizePage'
const adSizeRoute = [
  { path: '/admin/size', element: <AdSizePage /> },
]

export default adSizeRoute
