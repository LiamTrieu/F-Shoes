export const sanPham = {
  dark: {
    colorTable: '#30334E',
  },
  light: { colorTable: '#F3F5F9' },
}
