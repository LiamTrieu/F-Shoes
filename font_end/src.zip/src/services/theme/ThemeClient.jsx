import React from 'react'

export default function ThemeClient() {
  return <div>ThemeClient</div>
}
