import React from "react";

export default function Home() {
  return <div>Đây là trang home</div>;
}
