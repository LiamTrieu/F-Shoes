import React from "react";

export default function Product() {
  return <div>Đây là trang sản phẩm</div>;
}
