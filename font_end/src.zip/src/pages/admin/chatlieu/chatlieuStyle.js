export const spButton = {
  fontWeight: '600',
  letterSpacing: '1px',
  borderRadius: '10px',
  textTransform: 'none',
}

export const spTextSeacrh = {
  '& .MuiOutlinedInput-root:hover': {
    '& fieldset': { borderColor: 'gray' },
  },
}
