import React from 'react'

export default function AdProductDetailUpdate() {
  return <div>AdProductDetailUpdate</div>
}
