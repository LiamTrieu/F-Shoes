import React from "react";

export default function AdLoginPage() {
  return <div>Đây là trang login</div>;
}
