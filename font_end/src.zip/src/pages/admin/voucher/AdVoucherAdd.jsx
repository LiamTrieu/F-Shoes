import {
  Button,
  Dialog,
  DialogActions,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  InputAdornment,
  Pagination,
  Paper,
  Radio,
  RadioGroup,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from '@mui/material'
import { DateTimePicker, LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import React, { useState } from 'react'
import voucherApi from '../../../api/admin/voucher/VoucherApi'
import { useNavigate } from 'react-router-dom'
import dayjs from 'dayjs'
import confirmSatus from '../../../components/comfirmSwal'
import { toast } from 'react-toastify'
import { useTheme } from '@emotion/react'
// import PercentIcon from "@mui/icons-material/Percent";

export default function AdVoucherAdd() {
  const initialVoucher = {
    code: '',
    name: '',
    value: 0,
    maximumValue: 0,
    type: 'true',
    minimumAmount: 0,
    quantity: 0,
    startDate: '',
    endDate: '',
    status: 1,
  }
  const theme = useTheme()
  const navigate = useNavigate()
  const [isSelectVisible, setIsSelectVisible] = useState(false)
  const [voucherAdd, setVoucherAdd] = useState(initialVoucher)
  const [openCustomer, setOpenCustomer] = useState(false)
  const [listCustomer, setListCustomer] = useState([])
  const [initPage, setInitPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [dataFetched, setDataFetched] = useState(false)

  const handleTypeChange = (event) => {
    const newValue = event.target.value === 'true'
    setVoucherAdd({ ...voucherAdd, type: Boolean(event.target.value) })
    setIsSelectVisible(newValue === false)
  }

  const handleVoucherAdd = (voucherAdd) => {
    console.log('voucher :', voucherAdd)
    const title = 'Xác nhận thêm mới voucher?'
    const text = ''
    confirmSatus(title, text, theme).then((result) => {
      if (result.isConfirmed) {
        voucherApi
          .addVoucher(voucherAdd)
          .then(() => {
            toast.success('Thêm mới voucher thành công', {
              position: toast.POSITION.TOP_RIGHT,
            })
            navigate('/admin/voucher')
          })
          .catch(() => {
            toast.error('Thêm mới voucher thất bại', {
              position: toast.POSITION.TOP_RIGHT,
            })
          })
      }
    })
  }

  const handelCustomeFill = (initPage) => {
    voucherApi
      .getPageCustomer(initPage - 1)
      .then((response) => {
        setListCustomer(response.data.data.content)
        setTotalPages(response.data.data.totalPages)
        setOpenCustomer(true)
        setDataFetched(true)
      })
      .catch((error) => {
        setDataFetched(false)
      })
  }

  const handelOnchangePage = (page) => {
    setInitPage(page)
    handelCustomeFill(page - 1)
  }
  return (
    <div>
      <Paper elevation={3} sx={{ mt: 2, mb: 2, padding: 1 }}>
        <Grid container spacing={2}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={11.8}>
            <h1>Thêm mới Voucher</h1>
          </Grid>
          <Grid item xs={0.1}></Grid>
        </Grid>
        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Mã voucher"
              type="text"
              size="small"
              fullWidth
              onChange={(e) => setVoucherAdd({ ...voucherAdd, code: e.target.value })}
            />
          </Grid>
          <Grid item xs={0.6}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Tên voucher"
              type="text"
              size="small"
              fullWidth
              onChange={(e) => setVoucherAdd({ ...voucherAdd, name: e.target.value })}
            />
          </Grid>
          <Grid item xs={0.3}></Grid>
        </Grid>
        {/*------------------------------------------------------------------------------------- */}

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Giá trị"
              type="number"
              size="small"
              fullWidth
              onChange={(e) => setVoucherAdd({ ...voucherAdd, value: Number(e.target.value) })}
              InputProps={{
                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                inputProps: { min: 0, max: 100 },
              }}
            />
          </Grid>
          <Grid item xs={0.6}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Giá trị tối đa"
              type="number"
              size="small"
              fullWidth
              onChange={(e) =>
                setVoucherAdd({
                  ...voucherAdd,
                  maximumValue: Number(e.target.value),
                })
              }
              InputProps={{
                endAdornment: <InputAdornment position="end">VNĐ</InputAdornment>,
              }}
            />
          </Grid>
          <Grid item xs={0.3}></Grid>
        </Grid>
        {/**?------------------------------------------------------------------------------------------------------- */}

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Số lượng"
              type="number"
              variant="outlined"
              size="small"
              fullWidth
              onChange={(e) =>
                setVoucherAdd({
                  ...voucherAdd,
                  quantity: Number(e.target.value),
                })
              }
            />
          </Grid>
          <Grid item xs={0.6}></Grid>
          <Grid item xs={5.5}>
            <TextField
              label="Điều kiện"
              type="number"
              size="small"
              fullWidth
              onChange={(e) =>
                setVoucherAdd({
                  ...voucherAdd,
                  minimumAmount: Number(e.target.value),
                })
              }
              InputProps={{
                endAdornment: <InputAdornment position="end">VNĐ</InputAdornment>,
              }}
            />
          </Grid>
          <Grid item xs={0.3}></Grid>
        </Grid>
        {/**?------------------------------------------------------------------------------------------------------- */}

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={5.5}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DateTimePicker
                format={'DD-MM-YYYY HH:mm:ss'}
                onChange={(e) =>
                  setVoucherAdd({
                    ...voucherAdd,
                    startDate: dayjs(e).format('DD-MM-YYYY HH:mm:ss'),
                  })
                }
                label="Từ ngày"
                sx={{ width: '100%' }}
              />
            </LocalizationProvider>
          </Grid>
          <Grid item xs={0.6}></Grid>
          <Grid item xs={5.5}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DateTimePicker
                format={'DD-MM-YYYY HH:mm:ss'}
                onChange={(e) =>
                  setVoucherAdd({
                    ...voucherAdd,
                    endDate: dayjs(e).format('DD-MM-YYYY HH:mm:ss'),
                  })
                }
                label="Đến ngày"
                sx={{ width: '100%' }}
              />
            </LocalizationProvider>
          </Grid>
          <Grid item xs={0.3}></Grid>
        </Grid>
        {/**?------------------------------------------------------------------------------------------------------- */}

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.1}></Grid>
          <Grid item xs={3}>
            <FormControl size="small">
              <FormLabel>Kiểu</FormLabel>
              <RadioGroup row>
                <FormControlLabel
                  name="typeAdd"
                  value={true}
                  control={<Radio />}
                  label="Tất cả"
                  onChange={(e) => handleTypeChange(e)}
                  checked={isSelectVisible === false}
                />
                <FormControlLabel
                  name="typeAdd"
                  value={false}
                  control={<Radio />}
                  label="Cá nhân"
                  onChange={(e) => handleTypeChange(e)}
                  checked={isSelectVisible === true}
                />
              </RadioGroup>
            </FormControl>
          </Grid>
          <Grid item xs={2}>
            {isSelectVisible && (
              <Button
                onClick={() => handelCustomeFill(initPage)}
                sx={{ width: 150, float: 'left', mt: 2.5 }}
                variant="contained">
                Chọn
              </Button>
            )}
            {openCustomer && (
              <Dialog open={openCustomer} setOpen={setOpenCustomer} title={'Chọn khách hàng'}>
                {dataFetched && (
                  <TableContainer component={Paper}>
                    <Table sx={{ width: 650 }} aria-label="simple table">
                      <TableHead>
                        <TableRow>
                          <TableCell align="center">Tên</TableCell>
                          <TableCell align="center">Số điện thoại</TableCell>
                          <TableCell align="center">Email</TableCell>
                          <TableCell align="center">Ngày sinh</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {listCustomer.map((row, index) => (
                          <TableRow
                            key={row.id}
                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                            <TableCell align="center">{row.fullName}</TableCell>
                            <TableCell align="center">{row.phoneNumber}</TableCell>
                            <TableCell align="center">{row.email}</TableCell>
                            <TableCell align="center">
                              {dayjs(row.dateBirth).format('DD-MM-YYYY')}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
                {!dataFetched && (
                  <p style={{ textAlign: 'center' }}>
                    <b>Không có dữ liệu</b>
                  </p>
                )}
                <Grid container sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}>
                  <Pagination
                    page={initPage}
                    onChange={(event, page) => handelOnchangePage(page)}
                    count={totalPages}
                    color="primary"
                  />
                </Grid>
                <DialogActions>
                  <Button onClick={() => setOpenCustomer(false)}>Xác nhận</Button>
                  <Button onClick={() => setOpenCustomer(false)}>Hủy</Button>
                </DialogActions>
              </Dialog>
            )}
          </Grid>
          <Grid item xs={6.6}></Grid>
          <Grid item xs={0.3}></Grid>
        </Grid>
        {/**?------------------------------------------------------------------------------------------------------- */}

        <Grid container spacing={2} sx={{ mb: 3 }}>
          <Grid item xs={0.5}></Grid>
          <Grid item xs={3}></Grid>
          <Grid item xs={5}></Grid>
          <Grid item xs={3}>
            <Button
              onClick={() => handleVoucherAdd(voucherAdd)}
              variant="contained"
              fullWidth
              color="success">
              Thêm mới
            </Button>
          </Grid>
        </Grid>
        <Grid item xs={0.5}></Grid>
      </Paper>
    </div>
  )
}
