import React from "react";

export default function CartProduct() {
  return <div>CartProduct</div>;
}
